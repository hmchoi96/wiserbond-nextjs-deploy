// lib/supportAI.ts
import { searchCorePapers } from "@/lib/coreApi";
import { callGPT } from "@/lib/ai/gpt"; // 기존 GPT 호출 함수

interface SupportInput {
  topic: string;
  industry?: string;
  country?: string;
  goal?: string;
  situation?: string;
  subIndustry?: string;
}

interface SupportSummary {
  summary: string;
  papers: {
    title: string;
    authors: string[];
    year: string;
    url: string;
  }[];
}

export async function getSupportSummary(input: SupportInput): Promise<SupportSummary> {
  const { topic, industry, country, goal, situation, subIndustry } = input;

  const queryParts = [topic, industry, country, goal, situation, subIndustry]
    .filter(Boolean)
    .join(" ");

  const papers = await searchCorePapers(queryParts, 5);

  const context = papers
    .map(
      (p, i) =>
        `#${i + 1} "${p.title}" (${p.year}) by ${p.authors.join(", ")}\nURL: ${p.url}`
    )
    .join("\n\n");

  const gptPrompt = `Based on the following academic papers, summarize the key insights related to "${topic}":\n\n${context}\n\nProvide a concise, professional summary with emphasis on implications for business or strategy.`;

  const summary = await callGPT(gptPrompt);

  return { summary, papers };
}
