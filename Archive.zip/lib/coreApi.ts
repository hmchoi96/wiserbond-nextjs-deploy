// lib/coreApi.ts
import axios from "axios";

export interface CorePaper {
  title: string;
  authors: string[];
  year: string;
  url: string;
  summary?: string;
}

export async function searchCorePapers(
  query: string,
  limit: number = 5
): Promise<CorePaper[]> {
  try {
    const response = await axios.get(
      `https://core.ac.uk:443/api-v2/search/${encodeURIComponent(query)}`,
      {
        params: {
          page: 1,
          pageSize: limit,
          metadata: true,
          fulltext: false,
        },
        headers: {
          Authorization: `Bearer ${process.env.CORE_API_KEY}`,
        },
      }
    );

    const papers: CorePaper[] = response.data.data.map((item: any) => ({
      title: item.title,
      authors: item.authors?.map((a: any) => a.name) || [],
      year: item.yearPublished,
      url: item.url,
    }));

    return papers;
  } catch (error) {
    console.error("❌ CORE API search failed:", error);
    return [];
  }
}
