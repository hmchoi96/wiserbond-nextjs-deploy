export type Paper = {
    title: string;
    abstract: string;
    doi: string;
    citationCount?: number;
  };
  